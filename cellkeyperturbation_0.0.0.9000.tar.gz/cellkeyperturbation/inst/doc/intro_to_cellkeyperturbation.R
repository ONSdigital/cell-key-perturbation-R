## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(cellkeyperturbation)

## -----------------------------------------------------------------------------
str(micro)

str(ptable_10_5)

perturbed_table <-create_perturbed_table(data_table = micro,
                                          record_key = "record_key",
                                          geog = c("var1"),
                                          tab_vars = c("var5","var8"),
                                          ptable = ptable_10_5)

str(perturbed_table)

